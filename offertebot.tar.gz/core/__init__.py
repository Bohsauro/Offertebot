# Core module for OfferteBot
